package com.in28minutes.rest.webservices.restfulwebservices.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserResource {
	

	public void add() {
		
	}

}
