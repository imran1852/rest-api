--insert into user values(10001, sysdate(), 'AB');
--insert into user values(10002, sysdate(), 'Jill');
--insert into user values(10003, sysdate(), 'Jam');
--insert into post values(11001, 'My First Post', 10001);
--insert into post values(11002, 'My Second Post', 10001);

insert into horse values(10001,'horse111');
insert into horse values(10002,'horse222');
insert into horse values(10003,'horse333');
insert into horse values(10004,'horse444');
insert into horse values(10005,'horse555');
insert into horse values(10006,'horse666');

insert into event values(50001,sysdate(),'start', 11111111,10001);
insert into event values(50002,sysdate(),'start', 22222222,10004);
insert into event values(50003,sysdate(),'finish', 33333333,10001);
insert into event values(50004,sysdate(),'start', 44444444,10002);




