package com.gateway.rest.webservices.workerprocessapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkerProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkerProcessApplication.class, args);
	}
}
