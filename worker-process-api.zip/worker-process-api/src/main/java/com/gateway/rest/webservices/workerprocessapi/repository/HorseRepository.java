package com.gateway.rest.webservices.workerprocessapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gateway.rest.webservices.workerprocessapi.event.Horse;

@Repository
public interface HorseRepository extends JpaRepository<Horse, Integer>{

}
