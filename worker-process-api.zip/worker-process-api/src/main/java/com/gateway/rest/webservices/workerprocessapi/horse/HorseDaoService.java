//package com.in28minutes.rest.webservices.restfulwebservices.horse;
//
//import java.math.BigInteger;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.Iterator;
//import java.util.List;
//
//import org.springframework.stereotype.Component;
//
//@Component
//public class HorseDaoService {
//	
//	private static List<Horse> horses = new ArrayList<>();
//
//	private static int horsesCount = 3;
//
//	static {
//	     horses.add(new Horse(1, "Horse111", BigInteger.valueOf(123)));
//	     horses.add(new Horse(1, "Horse222", BigInteger.valueOf(456)));
//	     horses.add(new Horse(1, "RHorse333", BigInteger.valueOf(789)));
//	}
//
//	public List<Horse> findAll() {
//		return horses;
//	}
//
//	public Horse save(Horse horse) {
//		if (horse.getId() == null) {
//			horse.setId(++horsesCount);
//		}
//		horses.add(horse);
//		return horse;
//	}
//
//	public Horse findOne(int id) {
//		for (Horse horse : horses) {
//			if (horse.getId() == id) {
//				return horse;
//			}
//		}
//		return null;
//	}
//
//	public Horse deleteById(int id) {
//		Iterator<Horse> iterator = horses.iterator();
//		while (iterator.hasNext()) {
//			Horse horse = iterator.next();
//			if (horse.getId() == id) {
//				iterator.remove();
//				return horse;
//			}
//		}
//		return null;
//	}
//
//}
