package com.gateway.rest.webservices.workerprocessapi.event;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gateway.rest.webservices.workerprocessapi.event.Horse;

@Component
public class EventDaoService {
	
	private static List<Event> events = new ArrayList<>();

	private static int eventsCount = 3;

	static {
		Horse horse1=new Horse(1,"abc");
		Horse horse2=new Horse(2,"efg");
		Horse horse3=new Horse(3,"qrs");
		
		events.add(new Event(111,"start", horse1, 123));
		events.add(new Event(222,"start", horse2,456));
		events.add(new Event(333,"start", horse3,789));

	}

	public List<Event> findAll() {
		return events;
	}

	public Event save(Event event) {
		if (event.getId() == 0) {
			event.setId(++eventsCount);
		}
		events.add(event);
		return event;
	}
}
