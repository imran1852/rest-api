package com.gateway.rest.webservices.workerprocessapi.event;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.gateway.rest.webservices.workerprocessapi.repository.EventRepository;



@RestController
public class EventResource {

@Autowired
private EventRepository service;

@GetMapping("/events")
public List<Event> retrieveAllEvents() {
	return service.findAll();
}

@PostMapping("/events")
public ResponseEntity<Object> createEvent(@RequestBody Event event) {
	System.out.println("before event: ****   "+event);
	Event savedEvent = service.save(event);
	// CREATED
	// /event/{id}     savedEvent.getId()
	System.out.println("after event: ****   "+event);
	
	URI location = ServletUriComponentsBuilder
		.fromCurrentRequest()
		.path("/{id}")
		.buildAndExpand(savedEvent.getId()).toUri();
	
	return ResponseEntity.created(location).build();
	
}
}
