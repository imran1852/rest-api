//package com.in28minutes.rest.webservices.restfulwebservices.horse;
//
//import java.net.URI;
//import java.util.List;
//
//import org.slf4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
//
//@RestController
//public class HorseResource {
//
//
//	@Autowired
//	private HorseDaoService service;
//
//	@GetMapping("/horses")
//	public List<Horse> retrieveAllHorses() {
//		return service.findAll();
//	}
//
//	@GetMapping("/horses/{id}")
//	public Horse retrieveHorse(@PathVariable int id) {
//		Horse horse = service.findOne(id);
//		
//		//if(horse==null)
//			//throw new HorseNotFoundException("id-"+ id);
//		
//		return horse;
//	}
//
//	@DeleteMapping("/horses/{id}")
//	public void deleteHorse(@PathVariable int id) {
//		Horse horse = service.deleteById(id);
//		
//		//if(horse==null)
//			//throw new HorseNotFoundException("id-"+ id);		
//	}
//
//	//
//	// input - details of horse
//	// output - CREATED & Return the created URI
//	@PostMapping("/horses")
//	public ResponseEntity<Object> createHorse(@RequestBody Horse horse) {
//		System.out.println("before horse: ****   "+horse);
//		Horse savedHorse = service.save(horse);
//		// CREATED
//		// /horse/{id}     savedHorse.getId()
//		System.out.println("after horse: ****   "+horse);
//		
//		URI location = ServletUriComponentsBuilder
//			.fromCurrentRequest()
//			.path("/{id}")
//			.buildAndExpand(savedHorse.getId()).toUri();
//		
//		return ResponseEntity.created(location).build();
//		
//	}
//}
