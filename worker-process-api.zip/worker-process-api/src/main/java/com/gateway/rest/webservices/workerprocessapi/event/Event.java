package com.gateway.rest.webservices.workerprocessapi.event;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;


@Entity
public class Event {
	@Id
	@GeneratedValue
	private int id;
	
	private String event_type;

	@ManyToOne
	private Horse horse;
    
	@Column(name =  "start_finish_time")
	private int time;
	
	@CreationTimestamp
	private LocalDateTime date_time; 
	
	protected Event() {}
	
	public Event(int id,String event_type, Horse horse, int time) {
		super();
		this.id=id;
		this.event_type = event_type;
		this.horse = horse;
		this.time = time;
	}

	public String getEvent_type() {
		return event_type;
	}

	public void setEvent_type(String event_type) {
		this.event_type = event_type;
	}

	public Horse getHorse() {
		return horse;
	}

	public void setHorse(Horse horse) {
		this.horse = horse;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Event [event_type=" + event_type + ", horse=" + horse + ", time=" + time + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
